# EDUMINDS APP

## Overview
EDUMINDS APP is a learning platform to teach local, practical skills through accessible mobile education and AI-powered assessments. This is a FastAPI backend application with a RESTful API.

## Project Structure
```
backend/
├── __init__.py         # Package initialization
├── main.py            # FastAPI app and route definitions
├── models.py          # SQLAlchemy database models
├── schemas.py         # Pydantic schemas for request/response validation
├── crud.py            # CRUD operations
├── database.py        # Database configuration
└── requirements.txt   # Python dependencies
```

## Technology Stack
- **Framework**: FastAPI
- **Database**: SQLite (eduminds.db)
- **ORM**: SQLAlchemy
- **Validation**: Pydantic V2
- **Server**: Uvicorn

## Database Models
- **Product**: Learning resources/courses with name, price, and description
- **Order**: Customer orders with customer_name and order_date
- **OrderItem**: Items in an order linking products and quantities

## API Endpoints

### Products
- `POST /products/` - Create a new product
- `GET /products/` - Get all products
- `GET /products/{product_id}` - Get a specific product

### Orders
- `POST /orders/` - Create a new order with items
- `GET /orders/` - Get all orders
- `GET /orders/{order_id}` - Get a specific order

## Development
The backend runs on port 5000 using Uvicorn with auto-reload enabled. CORS is configured to allow all origins for development.

## Recent Changes
- 2025-10-21: Initial setup for Replit environment
  - Fixed project structure (moved crud.py from backend/backend/ to backend/)
  - Added __init__.py to make backend a proper Python package
  - Updated Pydantic schemas from V1 to V2 (orm_mode → from_attributes)
  - Updated CRUD operations to use model_dump() instead of dict()
  - Configured workflow to run on port 5000
  - Added database and Python virtual environment to .gitignore
